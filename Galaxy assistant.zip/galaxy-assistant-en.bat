@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Galaxy Assistant

call :require_adb || exit /b 1

if /i "%~1"=="--battery" (
  set "non_interactive=1"
  goto battery
)

if /i "%~1"=="--install-camsung" (
  set "non_interactive=1"
  set "assume_yes=1"
  goto install_camsung
)

:menu
cls
echo ================================================================
echo Galaxy Assistant
echo ================================================================
echo 1. USB debugging instructions
echo 2. Disable forced camera shutter sound
echo 3. Restore camera shutter sound
echo 4. Check battery information
echo 5. Install Camsung
echo 6. Exit
echo.
set "choice="
set /p "choice=Choose an option: "
if "%choice%"=="1" goto debug_help
if "%choice%"=="2" goto silence
if "%choice%"=="3" goto restore
if "%choice%"=="4" goto battery
if "%choice%"=="5" goto install_camsung
if "%choice%"=="6" exit /b 0
goto menu

:require_adb
set "adb_exe="
if defined GALAXY_ASSISTANT_ADB set "adb_exe=%GALAXY_ASSISTANT_ADB%"
if not defined adb_exe if exist "%~dp0platform-tools\adb.exe" set "adb_exe=%~dp0platform-tools\adb.exe"
if not defined adb_exe if exist "%~dp0adb.exe" set "adb_exe=%~dp0adb.exe"
if not defined adb_exe for /f "delims=" %%A in ('where adb 2^>nul') do if not defined adb_exe set "adb_exe=%%A"
if not defined adb_exe (
  echo ADB was not found. Extract the complete ZIP again or install Android Platform Tools.
  pause
  exit /b 1
)
exit /b 0

:require_device
call "%adb_exe%" get-state 2>nul | findstr /x /c:"device" >nul
if errorlevel 1 (
  echo No authorized device was found. Check the USB cable and approve USB debugging on the phone.
  exit /b 1
)
exit /b 0

:debug_help
cls
echo 1. Open Settings ^> About phone ^> Software information.
echo 2. Tap Build number seven times.
echo 3. Open Developer options and enable USB debugging.
echo 4. Connect the phone and approve the authorization prompt.
pause
goto menu

:silence
cls
call :require_device || goto wait_menu
call "%adb_exe%" shell settings put system csc_pref_camera_forced_shuttersound_key 0
if errorlevel 1 (
  echo Failed to change the setting.
) else (
  echo The forced shutter-sound setting was disabled.
)
goto wait_menu

:restore
cls
call :require_device || goto wait_menu
call "%adb_exe%" shell settings put system csc_pref_camera_forced_shuttersound_key 1
if errorlevel 1 (
  echo Failed to restore the setting.
) else (
  echo The shutter-sound setting was restored.
)
goto wait_menu

:battery
cls
call :require_device || goto wait_menu
set "battery_log=%TEMP%\galaxy-assistant-%RANDOM%-%RANDOM%.txt"
call "%adb_exe%" shell dumpsys battery >"%battery_log%" 2>nul
if errorlevel 1 (
  echo Failed to read battery information.
  del /q "%battery_log%" >nul 2>&1
  goto wait_menu
)
set "level=N/A"
set "voltage=N/A"
set "health=N/A"
set "usage=N/A"
for /f "tokens=2 delims=:" %%A in ('findstr /r /c:"^[ ]*level:" "%battery_log%"') do set "level=%%A"
for /f "tokens=2 delims=:" %%A in ('findstr /r /c:"^[ ]*voltage:" "%battery_log%"') do set "voltage=%%A"
for /f "tokens=2 delims=:" %%A in ('findstr /c:"mSavedBatteryAsoc" "%battery_log%"') do set "health=%%A"
for /f "tokens=2 delims=:" %%A in ('findstr /c:"mSavedBatteryUsage" "%battery_log%"') do set "usage=%%A"
for %%V in (level voltage health usage) do for /f "tokens=*" %%A in ("!%%V!") do set "%%V=%%A"
set "health=!health:[=!"
set "health=!health:]=!"
set "usage=!usage:[=!"
set "usage=!usage:]=!"
set "voltage_text=%voltage% mV"
set "cycles=N/A"
set /a voltage_number=voltage 2>nul
if not errorlevel 1 (
  set /a voltage_whole=voltage_number / 1000, voltage_fraction=voltage_number %% 1000
  set "voltage_fraction=00!voltage_fraction!"
  set "voltage_text=!voltage_whole!.!voltage_fraction:~-3! V"
)
set /a usage_number=usage 2>nul
if not errorlevel 1 set /a cycles=usage_number / 100
echo Battery level: %level%%%
echo Battery voltage: %voltage_text%
echo Battery health: %health%%%
echo Estimated cycles: %cycles%
del /q "%battery_log%" >nul 2>&1
if defined non_interactive exit /b 0
goto wait_menu

:install_camsung
cls
set "action_result=1"
call :require_device || goto install_camsung_done
echo This checks the official GitHub release and installs the latest Camsung APK.
echo Source: https://github.com/ericswpark/camsung
echo.
if not defined assume_yes (
  choice /c YN /n /m "Continue? [Y/N]: "
  if errorlevel 2 (
    set "action_result=2"
    goto install_camsung_done
  )
)

set "camsung_api=https://api.github.com/repos/ericswpark/camsung/releases/latest"
set "camsung_version="
set "camsung_url="
set "camsung_sha256="
echo Checking the latest release...
for /f "tokens=1-3 delims=;" %%A in ('call powershell -NoProfile -Command "$ErrorActionPreference='Stop'; $r=Invoke-RestMethod -Headers @{'User-Agent'='Galaxy-Assistant'} -Uri $env:camsung_api; $a=$null; foreach($candidate in $r.assets){if($candidate.name -eq 'app-release.apk'){$a=$candidate; break}}; if(-not $a -or $r.tag_name -notmatch '^[0-9A-Za-z._-]+$' -or $a.digest -notmatch '^sha256:[0-9a-fA-F]{64}$'){exit 2}; Write-Output ($r.tag_name+';'+$a.browser_download_url+';'+$a.digest.Substring(7).ToUpperInvariant())" 2^>nul') do (
  set "camsung_version=%%A"
  set "camsung_url=%%B"
  set "camsung_sha256=%%C"
)
if not defined camsung_sha256 (
  echo Failed to verify the latest official release information.
  goto install_camsung_done
)
echo Latest Camsung version: !camsung_version!
set "camsung_apk=%TEMP%\camsung-!camsung_version!-%RANDOM%-%RANDOM%.apk"
set "download_sha="
echo Downloading the APK...
call powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri $env:camsung_url -OutFile $env:camsung_apk"
if errorlevel 1 (
  echo Failed to download the APK.
  del /q "%camsung_apk%" >nul 2>&1
  goto install_camsung_done
)

for /f "usebackq delims=" %%H in (`call powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 -LiteralPath $env:camsung_apk).Hash"`) do set "download_sha=%%H"
if /i not "!download_sha!"=="!camsung_sha256!" (
  echo APK integrity verification failed. Installation was stopped.
  del /q "%camsung_apk%" >nul 2>&1
  goto install_camsung_done
)

set "android_sdk="
set "android_sdk_number=0"
for /f "delims=" %%A in ('call "%adb_exe%" shell getprop ro.build.version.sdk 2^>nul') do set "android_sdk=%%A"
echo Android SDK: !android_sdk!
if defined android_sdk (
  set /a android_sdk_number=android_sdk 2>nul
)
if !android_sdk_number! GEQ 34 (
  call "%adb_exe%" install --bypass-low-target-sdk-block -r "%camsung_apk%"
) else (
  call "%adb_exe%" install -r "%camsung_apk%"
)
set "install_result=!errorlevel!"
del /q "%camsung_apk%" >nul 2>&1
if not "!install_result!"=="0" (
  echo Failed to install Camsung.
  set "action_result=!install_result!"
) else (
  echo Camsung was installed successfully.
  echo Open the app and enable its switch. Tap the lock icon to reapply it after boot.
  echo Set the phone to Vibrate or Mute when using the silent-camera feature.
  set "action_result=0"
)

:install_camsung_done
if defined non_interactive exit /b !action_result!
goto wait_menu

:wait_menu
echo.
pause
goto menu
